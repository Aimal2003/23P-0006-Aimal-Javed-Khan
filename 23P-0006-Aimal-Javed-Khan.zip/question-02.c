#include<stdio.h>

int collatz_length(int num);
int main(){
	int number;
	int digit;
	printf("enter number:");
	scanf("%d",&number);
	
	// if user enter a negative number, then we will multiply that number with negative sign to make it positive and store it in digit variable
	if(number<0){
		digit=-number;
	}
	else{
		digit=number;
	}
    printf("The longest collatz sequence is on %d, with a length of %d\n",digit,collatz_length(digit));
	return 0;
}
int collatz_length(int num){
	int len=1; // as stated num should always be greater than 1. here we will apply condition of even and odd number as told in the condition and then store in the len(length) variable and it will count it.
	 
	while(num!=1){
	if(num%2==0){
		num=num/2;
	}
	else if(num%2!=0){
		num=num*3+1;
	}	
	len++;
	}
	return len;
}
