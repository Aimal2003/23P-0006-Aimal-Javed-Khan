#include<stdio.h>
int main(){
	int array[20][20]; 
	int maximum_product=0; 
	
	printf("enter numbers in array:");
	for(int i=0;i<20;i++){
		for(int j=0;j<20;j++){
			scanf("%d\n",&array[i][j]); 
		}
	}
     // Checking  vertical product we will do row-4 such that it will iterate upto 17th column,a column with 4 adjacent elements will be iterated in order to avoid overflow. in k loop that 4 elements will added with rows
	
	for(int i=0;i<=20-4;i++){
		for(int j=0;j<20;j++){
			int product=1; 
			for(int k=0;k<4;k++){
				product*=array[i+k][j];
			}
			if(product>maximum_product){ // here putting condition if the product of these 4 numbers are greater than maximum than store it in maximum product.
				maximum_product=product;
			}
		}
	}
	
	// now for horizontal products  same method will be applied to it with j(column) we will put -4 comdition with j(columns).
	
	for(int i=0;i<20;i++){
		for(int j=0;j<=20-4;j++){
			int product=1;
			for(int k=0;k<4;k++){
				product*=array[i][j+k];
			}
			if(product>maximum_product){
				maximum_product=product;
			}
		}
	}
	
	// now for checking diagnols we will have to look both to rows and columns so we will apply -4 condition to both rows and columns and then added that to both i and j
	
	for(int i=0;i<=20-4;i++){
		for(int j=0;j<=20-4;j++){
			int product=1;
			for(int k=0;k<4;k++){
				product*=array[i+k][j+k];
			}
			if(product>maximum_product){
				maximum_product=product;
			}
		}
	} 
	printf("so the maximum product of 4 adjacent number is %d\n",maximum_product);
	return 0;
}
